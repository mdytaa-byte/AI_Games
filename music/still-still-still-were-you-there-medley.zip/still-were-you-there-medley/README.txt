Still, Still, Still / Were You There
A medley for SATB choir and piano

FILES
  still-still-still-were-you-there-medley.musicxml
      Open this in MuseScore, Finale, Dorico, or Noteflight.
  generate_medley.py
      Optional. Regenerates the MusicXML:  python3 generate_medley.py

VOICINGS
  A  Piano intro
  B  Still, Still, Still verse 1 — SA
  C  Still, Still, Still verse 2 — SATB
  D  Humming transition
  E  Were You There (crucified) — TB, SA hum
  F  Were You There (laid in the tomb) — SA, TB hum
  G  Were You There (He rose / Glory!) — SATB
  H  Coda — SATB, very peaceful

The piano should stay flowing (broken chords), not block-chord hymn style.
The "sun refused to shine" stanza may replace letter F.

Copyright: both tunes and the traditional English texts are public domain.
This SATB-and-piano arrangement is original and is not the 2025 hymnal setting.
